x = 1

while x <= 6:
    print(x)
    x = x + 1